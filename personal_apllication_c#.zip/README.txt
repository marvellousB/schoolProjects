Uygulamamızın bulunduğu dizin şu şekildedir:

152120221167_MerveBaşaran_Group12_B\Personal_Organizer_Application\Personal-Organizer-Application\PersonalApplication\bin\Debug\
OOP2_2_anaUygulama.exe


Reminder uygulamamızdaki bildirim 1dk gecikme ile gelmektedir.