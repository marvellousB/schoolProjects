﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Windows.Forms;

namespace Personal_Organizer_Application
{
    public partial class Reminder : Form
    {
        // Bellekteki hatırlatıcı listesi
        public static List<Alarm> alarmList = new List<Alarm>();
        // Kullanıcıya özel liste
        private List<Alarm> userAlarmList => alarmList.Where(a => a.User == LoginedUser.getInstance().UserGetSet.Username).ToList();

        private Timer reminderTimer;
        private DateTime lastCheck;
        private NotifyIcon notifyIcon;

        public Reminder()
        {
            InitializeComponent();
            ThemeManager.ApplyTheme(this);

            // NotifyIcon ayarı
            notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Visible = true,
                BalloonTipTitle = "Reminder"
            };

            // Timer kurulur
            lastCheck = DateTime.Now;
            reminderTimer = new Timer { Interval = 60000 }; // 60s
            reminderTimer.Tick += ReminderTimer_Tick;
            reminderTimer.Start();
        }

        private void Reminder_Load(object sender, EventArgs e)
        {
            // Grid doldur
            RefreshGrid();
        }

        private void BtnList_Click(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if ((!rdoMeeting.Checked && !rdoTask.Checked) || !dateTimePicker1.Checked
                || string.IsNullOrWhiteSpace(mtxtTime.Text)
                || string.IsNullOrWhiteSpace(txtSummary.Text)
                || string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Please fill in the blanks!", "Info",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var type = rdoMeeting.Checked ? "Meeting" : "Task";
            var alarm = new Alarm(
                LoginedUser.getInstance().UserGetSet.Username,
                type,
                dateTimePicker1.Value.ToShortDateString(),
                mtxtTime.Text,
                txtSummary.Text,
                txtDescription.Text);

            alarmList.Add(alarm);
            MessageBox.Show("Registration Successful!", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshGrid();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvRemainderList.SelectedRows.Count == 0) return;
            var alarm = (Alarm)dgvRemainderList.SelectedRows[0].DataBoundItem;
            alarmList.RemoveAll(a => a.Equals(alarm));
            MessageBox.Show("Reminder Deleted", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshGrid();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvRemainderList.SelectedRows.Count == 0) return;
            var selected = (Alarm)dgvRemainderList.SelectedRows[0].DataBoundItem;
            int idx = alarmList.FindIndex(a => a.Equals(selected));
            if (idx < 0) return;

            alarmList[idx].Type = rdoMeeting.Checked ? "Meeting" : "Task";
            alarmList[idx].Day = dateTimePicker1.Value.ToShortDateString();
            alarmList[idx].Time = mtxtTime.Text;
            alarmList[idx].Summary = txtSummary.Text;
            alarmList[idx].Description = txtDescription.Text;

            MessageBox.Show("Update Successful!", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            dgvRemainderList.DataSource = null;
            dgvRemainderList.DataSource = userAlarmList;
            if (dgvRemainderList.Columns.Count > 0)
                dgvRemainderList.Columns[0].Visible = false;
        }

        private void ReminderTimer_Tick(object sender, EventArgs e)
        {
            var now = DateTime.Now;
            foreach (var a in userAlarmList)
            {
                if (DateTime.TryParse($"{a.Day} {a.Time}", out DateTime scheduled))
                {
                    if (scheduled <= now && scheduled > lastCheck)
                    {
                        // Balon bildirimi
                        notifyIcon.BalloonTipText = $"{a.Summary}: {a.Description}";
                        notifyIcon.ShowBalloonTip(5000);

                        // Küçük form oluştur
                        var popup = new Form
                        {
                            StartPosition = FormStartPosition.CenterScreen,
                            Size = new Size(250, 100),
                            FormBorderStyle = FormBorderStyle.FixedToolWindow,
                            TopMost = true,
                            ShowInTaskbar = false
                        };

                        var lbl = new Label
                        {
                            Dock = DockStyle.Fill,
                            TextAlign = ContentAlignment.MiddleCenter,
                            Text = $"{a.Summary}\n{a.Description}"
                        };
                        popup.Controls.Add(lbl);
                        popup.Shown += (s, ev) => SystemSounds.Exclamation.Play();
                        popup.Show();

                        // 5 saniye sonra popup kapansın
                        var closeTimer = new Timer { Interval = 5000 };
                        closeTimer.Tick += (s2, e2) =>
                        {
                            closeTimer.Stop();
                            popup.Close();
                        };
                        closeTimer.Start();
                    }
                }
            }
            lastCheck = now;
        }

        private void Day_TimeShow_Tick(object sender, EventArgs e)
        {
            lblShowTime.Text = DateTime.Now.ToLongDateString()
                + Environment.NewLine + DateTime.Now.ToLongTimeString();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (var logOut = new LogOut()) logOut.ShowDialog();
            this.Close();
        }
    }
}