﻿// MainForm.Designer.cs
using System.Windows.Forms;

namespace Personal_Organizer_Application
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelMenu;
        private Panel panelContent;
        private Button btnPhoneBook;
        private Button btnNoteBook;
        private Button btnManagement;
        private Button btnCalculator;
        private Button btnReminder;
        private Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnReminder = new System.Windows.Forms.Button();
            this.btnCalculator = new System.Windows.Forms.Button();
            this.btnManagement = new System.Windows.Forms.Button();
            this.btnNoteBook = new System.Windows.Forms.Button();
            this.btnPhoneBook = new System.Windows.Forms.Button();
            this.panelContent = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.Controls.Add(this.btnLogout);
            this.panelMenu.Controls.Add(this.btnReminder);
            this.panelMenu.Controls.Add(this.btnCalculator);
            this.panelMenu.Controls.Add(this.btnManagement);
            this.panelMenu.Controls.Add(this.btnNoteBook);
            this.panelMenu.Controls.Add(this.btnPhoneBook);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(200, 600);
            this.panelMenu.TabIndex = 1;
            // 
            // btnLogout
            // 
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Location = new System.Drawing.Point(0, 560);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(200, 40);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "Logout";
            // 
            // btnReminder
            // 
            this.btnReminder.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReminder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReminder.Location = new System.Drawing.Point(0, 200);
            this.btnReminder.Name = "btnReminder";
            this.btnReminder.Size = new System.Drawing.Size(200, 50);
            this.btnReminder.TabIndex = 1;
            this.btnReminder.Text = "Reminder";
            // 
            // btnCalculator
            // 
            this.btnCalculator.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalculator.Location = new System.Drawing.Point(0, 150);
            this.btnCalculator.Name = "btnCalculator";
            this.btnCalculator.Size = new System.Drawing.Size(200, 50);
            this.btnCalculator.TabIndex = 2;
            this.btnCalculator.Text = "Salary Calculator";
            // 
            // btnManagement
            // 
            this.btnManagement.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManagement.Location = new System.Drawing.Point(0, 100);
            this.btnManagement.Name = "btnManagement";
            this.btnManagement.Size = new System.Drawing.Size(200, 50);
            this.btnManagement.TabIndex = 3;
            this.btnManagement.Text = "User Management";
            // 
            // btnNoteBook
            // 
            this.btnNoteBook.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNoteBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNoteBook.Location = new System.Drawing.Point(0, 50);
            this.btnNoteBook.Name = "btnNoteBook";
            this.btnNoteBook.Size = new System.Drawing.Size(200, 50);
            this.btnNoteBook.TabIndex = 4;
            this.btnNoteBook.Text = "Notes";
            // 
            // btnPhoneBook
            // 
            this.btnPhoneBook.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPhoneBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPhoneBook.Location = new System.Drawing.Point(0, 0);
            this.btnPhoneBook.Name = "btnPhoneBook";
            this.btnPhoneBook.Size = new System.Drawing.Size(200, 50);
            this.btnPhoneBook.TabIndex = 5;
            this.btnPhoneBook.Text = "Phone Book";
            // 
            // panelContent
            // 
            this.panelContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContent.Location = new System.Drawing.Point(200, 0);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new System.Drawing.Size(700, 600);
            this.panelContent.TabIndex = 0;
            this.panelContent.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContent_Paint);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelMenu);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personal Organizer";
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }
    }
}
