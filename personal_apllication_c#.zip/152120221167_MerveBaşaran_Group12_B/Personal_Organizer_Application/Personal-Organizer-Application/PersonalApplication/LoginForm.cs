﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Personal_Organizer_Application
{
    public partial class LoginForm : Form
    {
        public static List<User> userList = new List<User>();
        public static string path = "mydb.csv";
        public static LoginForm Form1Instance;
        LogOut logOut = new LogOut();
        RegisterForm register = new RegisterForm();

        public LoginForm()
        {
            InitializeComponent();
            Form1Instance = this;
            Util.LoadCsv(userList, path);
            ThemeManager.ApplyTheme(this);

            // 1) lblMesaj'ı ortala
            lblMesaj.AutoSize = false;
            lblMesaj.Width = this.ClientSize.Width;
            lblMesaj.Height = 30;
            lblMesaj.Location = new Point(0, btnLogin.Bottom + 10);
            lblMesaj.TextAlign = ContentAlignment.MiddleCenter;
            lblMesaj.Anchor = AnchorStyles.Top
                                | AnchorStyles.Left
                                | AnchorStyles.Right;
            lblMesaj.Visible = false;

            // 2) btnSignUp'a çerçeve ve hover rengi ver
            btnSignUp.FlatStyle = FlatStyle.Flat;
            btnSignUp.FlatAppearance.BorderSize = 2;
            btnSignUp.FlatAppearance.BorderColor = ThemeManager.AccentColor;
            btnSignUp.FlatAppearance.MouseOverBackColor = ThemeManager.SecondaryColor;
            btnSignUp.FlatAppearance.MouseDownBackColor = ThemeManager.PrimaryColor;
            btnSignUp.ForeColor = ThemeManager.TextColor;

            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.FlatAppearance.BorderSize = 2;
            btnLogin.FlatAppearance.BorderColor = ThemeManager.AccentColor;
            btnLogin.FlatAppearance.MouseOverBackColor = ThemeManager.SecondaryColor;
            btnLogin.FlatAppearance.MouseDownBackColor = ThemeManager.PrimaryColor;
            btnLogin.ForeColor = ThemeManager.TextColor;

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtPassword.Text = "";
            lblMesaj.Text = "";
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string password = txtPassword.Text;

            foreach (var user in userList)
            {
                if (user.IsValid(username, password))
                {
                    LoginedUser.getInstance().UserGetSet = user;
                    lblMesaj.BackColor = Color.Green;
                    lblMesaj.Text = "Başarılı";
                    lblMesaj.Visible = true;
                    Delay.Start();
                    return;
                }
            }

            lblMesaj.BackColor = Color.Red;
            lblMesaj.Text = "Hatalı Giriş";
            lblMesaj.Visible = true;
            txtName.Text = "";
            txtPassword.Text = "";
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            register.ShowDialog();
            if (register.IsDisposed)
                this.Show();
        }

        private void Delay_Tick(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtPassword.Text = "";
            lblMesaj.Text = "";
            Delay.Enabled = false;
            this.Hide();

            if (logOut.ShowDialog() == DialogResult.Cancel)
                this.Close();
            else
            {
                using (var frm = new LoginForm())
                    if (frm.ShowDialog() == DialogResult.Cancel)
                        this.Close();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
            => txtPassword.UseSystemPasswordChar = false;

        private void pictureBox5_Click(object sender, EventArgs e)
            => txtPassword.UseSystemPasswordChar = true;

        // Bitmap'i tema rengine göre boya
        private Bitmap TintBitmap(Bitmap src, Color targetColor)
        {
            var bmp = new Bitmap(src.Width, src.Height);
            using (var g = Graphics.FromImage(bmp))
            {
                float r = targetColor.R / 255f;
                float gco = targetColor.G / 255f;
                float b = targetColor.B / 255f;

                var cm = new System.Drawing.Imaging.ColorMatrix(new float[][]
                {
                    new float[]{ r,   0,   0, 0, 0},
                    new float[]{ 0, gco,   0, 0, 0},
                    new float[]{ 0,   0,   b, 0, 0},
                    new float[]{ 0,   0,   0, 1, 0},
                    new float[]{ 0,   0,   0, 0, 1}
                });

                var ia = new System.Drawing.Imaging.ImageAttributes();
                ia.SetColorMatrix(cm);

                g.DrawImage(
                    src,
                    new Rectangle(0, 0, src.Width, src.Height),
                    0, 0, src.Width, src.Height,
                    GraphicsUnit.Pixel,
                    ia
                );
            }
            return bmp;
        }
    }
}
