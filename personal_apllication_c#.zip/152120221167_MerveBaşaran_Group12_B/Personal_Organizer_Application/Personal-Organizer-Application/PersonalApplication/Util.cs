﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace Personal_Organizer_Application
{
    /// <summary>
    /// Ortak yardımcı metodlar sınıfı
    /// </summary>
    public static class Util
    {
        // reminder.csv dosyasının kesin konumu (uygulama dizininde)
        public static readonly string ReminderFile = Path.Combine(Application.StartupPath, "reminder.csv");

        /// <summary>Verilen metnin SHA256 hash değerini hex string olarak döner.</summary>
        public static string ComputeStringToSha256Hash(string plainText)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(plainText));
                var sb = new StringBuilder(bytes.Length * 2);
                foreach (var b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        /// <summary>Email doğrulama (küçük harfli alias).</summary>
        public static bool isEmailValid(string email) => IsEmailValid(email);

        /// <summary>Email adresinin geçerli formata sahip olup olmadığını kontrol eder.</summary>
        private static readonly Regex EmailRegex = new Regex(
            @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.(com|org|net|edu|gov|mil|biz|info|mobi)(\.[A-Z]{2})?$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);
        public static bool IsEmailValid(string email)
            => !string.IsNullOrWhiteSpace(email) && EmailRegex.IsMatch(email);

        /// <summary>Dosya yolundaki resmi base64 string olarak döner.</summary>
        public static string ImageToBase64(string path)
        {
            try { return Convert.ToBase64String(File.ReadAllBytes(path)); }
            catch { return null; }
        }

        /// <summary>Base64 string'i Image nesnesine dönüştürür.</summary>
        public static Image Base64ToImage(string base64String)
        {
            if (string.IsNullOrWhiteSpace(base64String))
                return null;

            var comma = base64String.IndexOf(',');
            var pureBase64 = comma >= 0 ? base64String.Substring(comma + 1) : base64String;
            pureBase64 = pureBase64.Trim().Trim('"').Replace("\r", "").Replace("\n", "");

            byte[] bytes;
            try { bytes = Convert.FromBase64String(pureBase64); }
            catch (FormatException fe)
            {
                Debug.WriteLine($"[Base64ToImage] Invalid Base64: {pureBase64.Substring(0, Math.Min(50, pureBase64.Length))}...");
                throw new ArgumentException("Base64 dizgesi geçerli bir görsel içermiyor.", fe);
            }

            using (var ms = new MemoryStream(bytes))
            {
                Image img;
                try { img = Image.FromStream(ms, false, true); }
                catch (ArgumentException ae)
                {
                    Debug.WriteLine($"[Base64ToImage] Stream byte count: {bytes.Length}, header: {string.Join(",", bytes.Take(8))}");
                    throw new ArgumentException("Stream geçerli bir resim verisine sahip değil.", ae);
                }
                var result = new Bitmap(img);
                img.Dispose();
                return result;
            }
        }
        public static void LoadPhoneBook(List<Phone> phoneList, string path)
        {
            phoneList.Clear();
            try
            {
                using (var reader = new StreamReader(path))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        var values = line.Split(',');
                        string user = values[0];
                        string name = values[1];
                        string surname = values[2];
                        string number = values[3];
                        string address = values[4];
                        string description = values[5];
                        string mail = values[6];
                        phoneList.Add(new Phone(user, name, surname, number, address, description, mail));
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        public static void SavePhoneBook(List<Phone> phoneList, string path)
        {
            using (var writer = new StreamWriter(path))
            {
                foreach (Phone number in phoneList)
                {
                    writer.WriteLine(number.toString());
                }
            }
        }

        public static void SaveNotebook(List<Notes> listNote, string path)
        {
            using (var writer = new StreamWriter(path))
            {
                foreach (Notes item in listNote)
                {
                    if (item.Note.Contains(System.Environment.NewLine))
                    {
                        item.Note = Regex.Escape(item.Note);
                        if (item.Note.Contains(","))
                        {
                            item.Note = item.Note.Replace(",", "#");
                            writer.WriteLine(item.toString());
                        }
                        else
                        {
                            writer.WriteLine(item.toString());
                        }
                    }
                    else
                    {
                        if (item.Note.Contains(","))
                        {
                            item.Note = item.Note.Replace(",", "#");
                        }
                        if (item.Note.Contains("\\n"))
                        {
                            item.Note = Regex.Escape(item.Note);
                        }
                        else
                        {
                            writer.WriteLine(item.toString());
                        }
                    }
                }
            }
        }
        public static List<Notes> LoadNotebook(string path)
        {
            List<Notes> listBook = new List<Notes>();
            try
            {
                StreamReader sr = new StreamReader(path);
                string notes;
                notes = sr.ReadLine();
                while (notes != null)
                {
                    string[] pieces = notes.Split(',');
                    string username = pieces[0];
                    string not = pieces[1];
                    Notes note1 = new Notes(username, not);
                    if (LoginedUser.getInstance().UserGetSet.Username == username)
                    {
                        note1.Note = Regex.Unescape(not);
                        if (note1.Note.Contains("#"))
                        {
                            note1.Note = note1.Note.Replace("#", ",");
                        }
                        listBook.Add(note1);
                    }
                    notes = sr.ReadLine();
                }
                sr.Close();
                sr.Dispose();
            }
            catch (Exception)
            {
            }
            return listBook;
        }

        // Diğer CSV işlemleri...
        public static void LoadCsv(List<User> userList, string path)
        {
            userList.Clear();
            try
            {
                using (var reader = new StreamReader(path))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        var values = line.Split(',');
                        string username = values[0];
                        string password = values[1];
                        bool rememberme = (values[2]).Equals("1") ? true : false;
                        string usertypes = values[3];
                        string name = values[4];
                        string surname = values[5];
                        string phonenumber = values[6];
                        string address = values[7];
                        if (address.Contains("#"))
                        {
                            address = address.Replace("#", ",");
                        }
                        string email = values[8];
                        string photo = values[9];
                        string salary = values[10];
                        userList.Add(new User(username, password, rememberme, usertypes, name, surname, phonenumber, address, email, photo, salary));
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        public static void SaveCsv(List<User> userList, string path)
        {
            using (var writer = new StreamWriter(path))
            {
                foreach (User user in userList)
                {
                    if (user.Address.Contains(","))
                    {
                        user.Address = user.Address.Replace(",", "#");
                    }
                    writer.WriteLine(user.toString());
                }
            }
        }



        /// <summary>Hatırlatıcı listesini CSV'den okur.</summary>
        public static void LoadReminder(List<Alarm> list)
        {
            list.Clear();
            if (!File.Exists(ReminderFile)) return;
            foreach (var line in File.ReadAllLines(ReminderFile))
            {
                var cols = line.Split(',');
                if (cols.Length < 6) continue;
                list.Add(new Alarm(cols[0], cols[1], cols[2], cols[3], cols[4], cols[5]));
            }
        }

        /// <summary>Hatırlatıcı listesini CSV'ye yazar.</summary>
        public static void SaveReminder(List<Alarm> list)
        {
            var lines = list.Select(a => a.ToString());
            File.WriteAllLines(ReminderFile, lines);
        }

        /// <summary>O anki hatırlatıcıyı tetikler.</summary>
        public static void RingAlarm(List<Alarm> list)
        {
            // Güncel listeye yükle
            LoadReminder(list);
            var nowKey = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            foreach (var a in list)
            {
                var scheduled = a.Day + " " + a.Time;
                if (scheduled == nowKey)
                {
                    // uygulama içi bildirim
                    if (Form.ActiveForm != null)
                    {
                        Shake(Form.ActiveForm);
                        MessageBox.Show($"{a.Summary}\n{a.Description}", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    break;
                }
            }
        }


        /// <summary>Formu sallar.</summary>
        public static void Shake(Form form)
        {
            var original = form.Location;
            var rnd = new Random();
            const int amplitude = 10;
            for (int i = 0; i < 70; i++)
            {
                form.Location = new Point(
                    original.X + rnd.Next(-amplitude, amplitude),
                    original.Y + rnd.Next(-amplitude, amplitude)
                );
                Thread.Sleep(5);
            }
            form.Location = original;
        }
    }
}
