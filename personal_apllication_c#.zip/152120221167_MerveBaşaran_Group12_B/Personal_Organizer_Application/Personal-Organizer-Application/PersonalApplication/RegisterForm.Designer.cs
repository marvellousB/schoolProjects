﻿namespace Personal_Organizer_Application
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblNewKayıt = new System.Windows.Forms.Label();
            this.lblnewPassword = new System.Windows.Forms.Label();
            this.txtNewName = new System.Windows.Forms.TextBox();
            this.txtNewPass = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.TxtSurname = new System.Windows.Forms.TextBox();
            this.TxtName = new System.Windows.Forms.TextBox();
            this.LblSurname = new System.Windows.Forms.Label();
            this.LnlName = new System.Windows.Forms.Label();
            this.TxtAddress = new System.Windows.Forms.TextBox();
            this.LblAddress = new System.Windows.Forms.Label();
            this.LblPhoneNumber = new System.Windows.Forms.Label();
            this.TxtEmail = new System.Windows.Forms.TextBox();
            this.LblPhoto = new System.Windows.Forms.Label();
            this.LblEmail = new System.Windows.Forms.Label();
            this.MTxtPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.BtnImagePath = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.LblPath = new System.Windows.Forms.Label();
            this.PicPhoto = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.White;
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRegister.Font = new System.Drawing.Font("Arial", 10F);
            this.btnRegister.ForeColor = System.Drawing.Color.Black;
            this.btnRegister.Location = new System.Drawing.Point(279, 267);
            this.btnRegister.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(101, 28);
            this.btnRegister.TabIndex = 9;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblNewKayıt
            // 
            this.lblNewKayıt.AutoSize = true;
            this.lblNewKayıt.Font = new System.Drawing.Font("Arial", 10F);
            this.lblNewKayıt.Location = new System.Drawing.Point(41, 7);
            this.lblNewKayıt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNewKayıt.Name = "lblNewKayıt";
            this.lblNewKayıt.Size = new System.Drawing.Size(88, 19);
            this.lblNewKayıt.TabIndex = 1;
            this.lblNewKayıt.Text = "Username:";
            // 
            // lblnewPassword
            // 
            this.lblnewPassword.AutoSize = true;
            this.lblnewPassword.Font = new System.Drawing.Font("Arial", 10F);
            this.lblnewPassword.Location = new System.Drawing.Point(44, 33);
            this.lblnewPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblnewPassword.Name = "lblnewPassword";
            this.lblnewPassword.Size = new System.Drawing.Size(85, 19);
            this.lblnewPassword.TabIndex = 2;
            this.lblnewPassword.Text = "Password:";
            // 
            // txtNewName
            // 
            this.txtNewName.Font = new System.Drawing.Font("Arial", 10F);
            this.txtNewName.Location = new System.Drawing.Point(135, 7);
            this.txtNewName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNewName.Name = "txtNewName";
            this.txtNewName.Size = new System.Drawing.Size(126, 27);
            this.txtNewName.TabIndex = 1;
            // 
            // txtNewPass
            // 
            this.txtNewPass.Font = new System.Drawing.Font("Arial", 10F);
            this.txtNewPass.Location = new System.Drawing.Point(135, 33);
            this.txtNewPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNewPass.Name = "txtNewPass";
            this.txtNewPass.Size = new System.Drawing.Size(126, 27);
            this.txtNewPass.TabIndex = 2;
            this.txtNewPass.UseSystemPasswordChar = true;
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(239, 279);
            this.lblState.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(0, 16);
            this.lblState.TabIndex = 5;
            // 
            // TxtSurname
            // 
            this.TxtSurname.Font = new System.Drawing.Font("Arial", 10F);
            this.TxtSurname.Location = new System.Drawing.Point(135, 83);
            this.TxtSurname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtSurname.Name = "TxtSurname";
            this.TxtSurname.Size = new System.Drawing.Size(126, 27);
            this.TxtSurname.TabIndex = 4;
            // 
            // TxtName
            // 
            this.TxtName.Font = new System.Drawing.Font("Arial", 10F);
            this.TxtName.Location = new System.Drawing.Point(135, 59);
            this.TxtName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtName.Name = "TxtName";
            this.TxtName.Size = new System.Drawing.Size(126, 27);
            this.TxtName.TabIndex = 3;
            // 
            // LblSurname
            // 
            this.LblSurname.AutoSize = true;
            this.LblSurname.Font = new System.Drawing.Font("Arial", 10F);
            this.LblSurname.Location = new System.Drawing.Point(49, 83);
            this.LblSurname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblSurname.Name = "LblSurname";
            this.LblSurname.Size = new System.Drawing.Size(80, 19);
            this.LblSurname.TabIndex = 25;
            this.LblSurname.Text = "Surname:";
            // 
            // LnlName
            // 
            this.LnlName.AutoSize = true;
            this.LnlName.Font = new System.Drawing.Font("Arial", 10F);
            this.LnlName.Location = new System.Drawing.Point(73, 59);
            this.LnlName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LnlName.Name = "LnlName";
            this.LnlName.Size = new System.Drawing.Size(56, 19);
            this.LnlName.TabIndex = 24;
            this.LnlName.Text = "Name:";
            // 
            // TxtAddress
            // 
            this.TxtAddress.Font = new System.Drawing.Font("Arial", 10F);
            this.TxtAddress.Location = new System.Drawing.Point(135, 135);
            this.TxtAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtAddress.Multiline = true;
            this.TxtAddress.Name = "TxtAddress";
            this.TxtAddress.Size = new System.Drawing.Size(126, 42);
            this.TxtAddress.TabIndex = 6;
            this.TxtAddress.UseSystemPasswordChar = true;
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Font = new System.Drawing.Font("Arial", 10F);
            this.LblAddress.Location = new System.Drawing.Point(55, 135);
            this.LblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(74, 19);
            this.LblAddress.TabIndex = 31;
            this.LblAddress.Text = "Address:";
            // 
            // LblPhoneNumber
            // 
            this.LblPhoneNumber.AutoSize = true;
            this.LblPhoneNumber.Font = new System.Drawing.Font("Arial", 10F);
            this.LblPhoneNumber.Location = new System.Drawing.Point(6, 108);
            this.LblPhoneNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPhoneNumber.Name = "LblPhoneNumber";
            this.LblPhoneNumber.Size = new System.Drawing.Size(123, 19);
            this.LblPhoneNumber.TabIndex = 30;
            this.LblPhoneNumber.Text = "Phone Number:";
            // 
            // TxtEmail
            // 
            this.TxtEmail.Font = new System.Drawing.Font("Arial", 10F);
            this.TxtEmail.Location = new System.Drawing.Point(135, 178);
            this.TxtEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.Size = new System.Drawing.Size(126, 27);
            this.TxtEmail.TabIndex = 7;
            // 
            // LblPhoto
            // 
            this.LblPhoto.AutoSize = true;
            this.LblPhoto.Font = new System.Drawing.Font("Arial", 10F);
            this.LblPhoto.Location = new System.Drawing.Point(73, 209);
            this.LblPhoto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPhoto.Name = "LblPhoto";
            this.LblPhoto.Size = new System.Drawing.Size(56, 19);
            this.LblPhoto.TabIndex = 37;
            this.LblPhoto.Text = "Photo:";
            // 
            // LblEmail
            // 
            this.LblEmail.AutoSize = true;
            this.LblEmail.Font = new System.Drawing.Font("Arial", 10F);
            this.LblEmail.Location = new System.Drawing.Point(69, 178);
            this.LblEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblEmail.Name = "LblEmail";
            this.LblEmail.Size = new System.Drawing.Size(60, 19);
            this.LblEmail.TabIndex = 36;
            this.LblEmail.Text = "E-Mail:";
            // 
            // MTxtPhoneNumber
            // 
            this.MTxtPhoneNumber.Font = new System.Drawing.Font("Arial", 10F);
            this.MTxtPhoneNumber.Location = new System.Drawing.Point(135, 108);
            this.MTxtPhoneNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MTxtPhoneNumber.Mask = "(999) 000-0000";
            this.MTxtPhoneNumber.Name = "MTxtPhoneNumber";
            this.MTxtPhoneNumber.Size = new System.Drawing.Size(126, 27);
            this.MTxtPhoneNumber.TabIndex = 5;
            // 
            // BtnImagePath
            // 
            this.BtnImagePath.BackColor = System.Drawing.Color.LightGray;
            this.BtnImagePath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnImagePath.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnImagePath.Location = new System.Drawing.Point(145, 209);
            this.BtnImagePath.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnImagePath.Name = "BtnImagePath";
            this.BtnImagePath.Size = new System.Drawing.Size(55, 25);
            this.BtnImagePath.TabIndex = 8;
            this.BtnImagePath.Text = "...";
            this.BtnImagePath.UseVisualStyleBackColor = false;
            this.BtnImagePath.Click += new System.EventHandler(this.BtnImagePath_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // LblPath
            // 
            this.LblPath.AutoSize = true;
            this.LblPath.Location = new System.Drawing.Point(266, 220);
            this.LblPath.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPath.Name = "LblPath";
            this.LblPath.Size = new System.Drawing.Size(0, 16);
            this.LblPath.TabIndex = 42;
            this.LblPath.Visible = false;
            // 
            // PicPhoto
            // 
            this.PicPhoto.Location = new System.Drawing.Point(213, 211);
            this.PicPhoto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PicPhoto.Name = "PicPhoto";
            this.PicPhoto.Size = new System.Drawing.Size(49, 44);
            this.PicPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicPhoto.TabIndex = 43;
            this.PicPhoto.TabStop = false;
            // 
            // RegisterForm
            // 
            this.AcceptButton = this.btnRegister;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(391, 301);
            this.Controls.Add(this.PicPhoto);
            this.Controls.Add(this.LblPath);
            this.Controls.Add(this.BtnImagePath);
            this.Controls.Add(this.MTxtPhoneNumber);
            this.Controls.Add(this.TxtEmail);
            this.Controls.Add(this.LblPhoto);
            this.Controls.Add(this.LblEmail);
            this.Controls.Add(this.TxtAddress);
            this.Controls.Add(this.LblAddress);
            this.Controls.Add(this.LblPhoneNumber);
            this.Controls.Add(this.TxtSurname);
            this.Controls.Add(this.TxtName);
            this.Controls.Add(this.LblSurname);
            this.Controls.Add(this.LnlName);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.txtNewPass);
            this.Controls.Add(this.txtNewName);
            this.Controls.Add(this.lblnewPassword);
            this.Controls.Add(this.lblNewKayıt);
            this.Controls.Add(this.btnRegister);
            this.Font = new System.Drawing.Font("Arial", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "RegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register Screen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegisterForm_FormClosing);
            this.Load += new System.EventHandler(this.KayıtFormu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label lblNewKayıt;
        private System.Windows.Forms.Label lblnewPassword;
        private System.Windows.Forms.TextBox txtNewName;
        private System.Windows.Forms.TextBox txtNewPass;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.TextBox TxtSurname;
        private System.Windows.Forms.TextBox TxtName;
        private System.Windows.Forms.Label LblSurname;
        private System.Windows.Forms.Label LnlName;
        private System.Windows.Forms.TextBox TxtAddress;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.Label LblPhoneNumber;
        private System.Windows.Forms.TextBox TxtEmail;
        private System.Windows.Forms.Label LblPhoto;
        private System.Windows.Forms.Label LblEmail;
        private System.Windows.Forms.MaskedTextBox MTxtPhoneNumber;
        private System.Windows.Forms.Button BtnImagePath;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label LblPath;
        private System.Windows.Forms.PictureBox PicPhoto;
    }
}